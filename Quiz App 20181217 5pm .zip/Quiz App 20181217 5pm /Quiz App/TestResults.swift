//
//  TestResults.swift
//  Quiz App
//
//  Created by tong chern haw on 3/12/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import Foundation

struct TestResults{
    var quizName :  String
    var quizResult: String
}
