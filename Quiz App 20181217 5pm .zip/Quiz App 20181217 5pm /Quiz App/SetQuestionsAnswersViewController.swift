//
//  SetQuestionsAnswersViewController.swift
//  Quiz App
//
//  Created by tong chern haw on 10/12/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import UIKit
import CoreData

class SetQuestionsAnswersViewController: UIViewController {

    var questionNo : Int = 1
    var quizAnswers : String = "AnswerFor1:AAnswerFor2:CAnswerFor3:DAnswerFor4:BAnswerFor5:D"
    var selectedAnswer : String = ""
    var blnRecordExist = false
    var response : QuizSettings!
    var labelQuestionLabel : Int = 1
    
    @IBOutlet weak var questionNoLabel: UILabel!
    @IBOutlet weak var selectedAnswerLabel : UILabel!
    
    @IBOutlet weak var nextQuestionButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
         print (response)
        questionNoLabel.text = "\(questionNo)"
        checkExistingRecords()
        loadAns()
        nextQuestionButton.isHidden = true
        
       
        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveAnswer(_ sender: Any) {
        saveAnswers()
    }
    
    @IBAction func nextQuestion(_ sender: Any) {
        questionNo = questionNo + 1
        if (questionNo <= response.noOfQuestions){
            labelQuestionLabel = questionNo
            selectedAnswerLabel.text = ""
            questionNoLabel.text = "\(labelQuestionLabel)"
            selectedAnswerLabel.text = ""
            nextQuestionButton.isHidden = true
        } else {
            nextQuestionButton.isHidden = true
        }
       
    }
    
    
    @IBAction func selectedChoice( _ sender: UIButton){
        var selectedChoice = sender.title(for: .normal)!
    
    selectedChoice = selectedChoice.replacingOccurrences(of: "Optional(", with: "")
    selectedChoice = selectedChoice.replacingOccurrences(of: ")", with: "")
        
        if( quizAnswers.contains("AnswerFor\(questionNo)")){
            
            quizAnswers=quizAnswers.replacingOccurrences(of:"AnswerFor\(questionNo):A" , with :"")
            
            quizAnswers=quizAnswers.replacingOccurrences(of:"AnswerFor\(questionNo):B" , with :"")
            
            quizAnswers=quizAnswers.replacingOccurrences(of:"AnswerFor\(questionNo):C" , with :"")
            
            quizAnswers=quizAnswers.replacingOccurrences(of:"AnswerFor\(questionNo):D" , with :"")
            
            
        }
    
        selectedAnswer = "\(selectedChoice)"
        
        quizAnswers = quizAnswers + "AnswerFor\(questionNo):\(selectedAnswer)"
        //   selectedAnswerLabel.text = "Selected answer for question \(labelQuestionLabel) is \(selectedAnswer)"
        
      //  questionNo = questionNo + 1
        nextQuestionButton.isHidden = false
        
        print ("Updated quiz answers string : \(quizAnswers)" )
        
        selectedAnswerLabel.text = "Selected answer for question \(questionNo) is \(selectedAnswer), Press Save to update"
    }
    
    func saveAnswers(){
        blnRecordExist=false
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "JavaAnswers", in: context)
        let newUpdate = NSManagedObject(entity: entity!, insertInto: context)
        
        print ("save Answers - Delete existing quiz answer to insert updated answer " )
        
        checkExistingRecords()
        if (blnRecordExist){
            deleteOldRecord(quizName:"Java 01")
        }
        print ("save Answers - Updating new quiz answers \(quizAnswers)" )
        
        newUpdate.setValue(quizAnswers, forKey: "quizAnswers")
       
        newUpdate.setValue("Java 01", forKey: "quizName")
       
       // loadAns()
    }
    
  
    
    @IBAction func loadSavedAnswers(_ sender: Any) {
        
        loadAns()
    }
    
    func deleteOldRecord(quizName:String){
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext =
            appDelegate.persistentContainer.viewContext
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "JavaAnswers")
        
        let quizName = "Java 01"
        fetchRequest.predicate = NSPredicate(format: "quizName == %@", quizName)
        
        do {
            let results = try managedContext.fetch(fetchRequest)
            
            
            var objectToDelete = results[0] as! NSManagedObject
            managedContext.delete(objectToDelete)
            print("Result deleted")
            
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    func loadAns(){
        
        
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext =
            appDelegate.persistentContainer.viewContext
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "JavaAnswers")
        
         let quizName = "Java 01"
       fetchRequest.predicate = NSPredicate(format: "quizName == %@", quizName)
        
        do {
            let results = try managedContext.fetch(fetchRequest)
            
            for data in results as! [NSManagedObject]{
                
                var quizAnswersStr : String = data.value(forKey: "quizAnswers") as! String
                
               print ("Loaded answers in Core data \(quizAnswersStr)")
                selectedAnswerLabel.text = "Answer set: \(quizAnswersStr)"
                
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
    }
    
 
    
    
    
    func checkExistingRecords() {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
       // var userSearch: String = "user1"
       var testType: String = "Java 01"
        
        var logExistingRecord = ""
        let managedContext =
            appDelegate.persistentContainer.viewContext
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "JavaAnswers")
        
       //  let quizName = "Java 01"
        fetchRequest.predicate = NSPredicate(format: "quizName == %@", testType)
        
        do {
            
        
            let results = try managedContext.fetch(fetchRequest)
            
            for data in results as! [NSManagedObject]{
                
              blnRecordExist=true
                logExistingRecord = data.value(forKey: "quizAnswers") as! String
             
                print ("Checking existing record - Answers for \(logExistingRecord)")
                
                
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        
    }
}
