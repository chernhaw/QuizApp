//
//  QuestionNAnswers.swift
//  Quiz App
//
//  Created by tong chern haw on 28/11/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import Foundation
struct QuestionNAnswers{
    var question : String // filename of the questions
    var correctAnswers : String
    var noOfChoice : Int
}
