
//
//  SearchByInfo.swift
//  Quiz App
//
//  Created by tong chern haw on 5/12/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import Foundation

struct SearchByInfo : Codable {
    var userID: String
    var userNRIC: String
    
}
