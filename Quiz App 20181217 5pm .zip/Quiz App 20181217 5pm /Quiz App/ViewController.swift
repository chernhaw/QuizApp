//
//  ViewController.swift
//  Quiz App
//
//  Created by tong chern haw on 13/11/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    let loginIDAdmin: String = "admin"
    let loginIDAdminPassword: String = "admin123"
    
    let loginIDUser: String = "user1"
    let loginIDUserPassword: String = "user123"
    
    let loginIDHRUser: String = "HRuser"
    let loginIDHRUserPassword: String = "hruser123"
    
    @IBOutlet weak var loginID: UITextField!
    
    @IBOutlet weak var loginPassword: UITextField!
    
    
    @IBOutlet weak var invalidLoginMsg: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBAction func Login(_ sender: Any) {
        
        
        
        var loginIDStr: String = loginID.text!
        var loginPasswordStr: String = loginPassword.text!
        
        var seguePathStr: String = ""
        print ("login id \(loginIDStr)" )
        
        print ("login password \(loginPasswordStr)" )
        
        if loginIDStr == loginIDAdmin && loginPasswordStr == loginIDAdminPassword
        {
            seguePathStr = "Admin"
            print (seguePathStr)
            performSegue(withIdentifier: "Admin", sender: nil)
        } else if loginIDStr == loginIDUser && loginPasswordStr == loginIDUserPassword
        {
            seguePathStr = "user"
            print (seguePathStr)
            performSegue(withIdentifier: "User", sender: nil)
        } else if loginIDStr == loginIDHRUser && loginPasswordStr == loginIDHRUserPassword
        {
            seguePathStr = "HR"
            print (seguePathStr)
            //HRuser
            performSegue(withIdentifier: "HRuser", sender: nil)
        } else {
            invalidLoginMsg.text="Invalid id or password"
            print ("Invalid user or password")
        }
        
    }
}

