//
//  QuizRecord.swift
//  Quiz App
//
//  Created by tong chern haw on 5/12/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

class QuizRecord {
    var userid: String
    var testtype: String
    var result: String
    var attempt: String
    
    init(userid: String, testtype: String, result: String, attempt: String){
        self.userid = userid
        self.testtype = testtype
        self.result = result
        self.attempt = attempt
    }
}

