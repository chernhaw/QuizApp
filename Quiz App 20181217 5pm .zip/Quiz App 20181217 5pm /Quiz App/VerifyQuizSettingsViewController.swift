//
//  VerifyQuizSettingsViewController.swift
//  Quiz App
//
//  Created by tong chern haw on 19/11/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import UIKit

class VerifyQuizSettingsViewController: UIViewController {
    
    @IBOutlet weak var quizDetailLabel: UILabel!
    
    
    var response : QuizSettings!
    
    var quizTrackNumber : String = ""
    
    
    
    // quiz detail codable
//    struct QuizInfoSaved: Codable {
//        let quizID : String
//        let questionType : String
//        let timeAllowed : String
//        let noOfQuestions : String
//    }
    
    // Quiz tracking codable
    struct JavaQuizIDSoFar : Codable {
        let quizID : String
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        displayQuizDetails ()
        
        // encode quiz details
        
       
    }
    
    func displayQuizDetails ()
    {
        quizDetailLabel.text = "Your Quiz Details \n\n QuizID : \(response.quizID) \n Type : \(response.questionType) \n Time Allowed : \(response.timeAllowed) \n No of Questions : \(response.noOfQuestions)"
        print(response)
    }
    
    
    
    
    @IBAction func upLoadQuizQuestionsButton(_ sender: Any) {
     saveQuizDetails()
        
    }
    
    func setQuizTrackingNumber (questionType : String){
        
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let archieveURL = documentsDirectory.appendingPathComponent("\(questionType)_tracking").appendingPathExtension("plist")
        let propertyListDecoder = PropertyListDecoder()
        
        if let retrievedLastJavaNotesData = try? Data(contentsOf: archieveURL),
            let decodedNote = try? propertyListDecoder.decode(JavaQuizIDSoFar.self, from: retrievedLastJavaNotesData) {
            print(decodedNote)
        
        
        }
    }
    func saveQuizDetails(){
        
         let quizInfoCodableToSave = QuizInfoSaved(quizID: response.quizID, questionType: response.questionType, timeAllowed: "\(response.timeAllowed)", noOfQuestions: "\(response.noOfQuestions)")
        
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let archieveURL = documentsDirectory.appendingPathComponent("\(response.quizID)").appendingPathExtension("plist")
        print ("file saved \(archieveURL)")
        
        let propertyListEncoder = PropertyListEncoder()
        let encodedNote = try? propertyListEncoder.encode(quizInfoCodableToSave)
        
        try? encodedNote?.write(to: archieveURL, options: .noFileProtection)
    
    
  //  func retrieveQuizDetails() {
        let propertyListDecoder = PropertyListDecoder()
        
        if let retrievedNoteData = try? Data(contentsOf: archieveURL),
            let decodedNote = try? propertyListDecoder.decode(QuizInfoSaved.self, from: retrievedNoteData) {
            print(decodedNote)
        }
  //  }
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.destination is SetQuestionsAnswersViewController{
            let vc = segue.destination as? SetQuestionsAnswersViewController
            vc?.response = response
        }
    }
}
