//
//  QuizInfoSaved.swift
//  Quiz App
//
//  Created by tong chern haw on 27/11/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import Foundation

struct QuizInfoSaved: Codable {
    let quizID : String
    let questionType : String
    let timeAllowed : String
    let noOfQuestions : String
}

