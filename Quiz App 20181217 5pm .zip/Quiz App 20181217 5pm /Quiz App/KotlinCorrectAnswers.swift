//
//  KotlinCorrectAnswers.swift
//  Quiz App
//
//  Created by tong chern haw on 29/11/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import Foundation
class KotlinCorrectAnswers{
    var answerlist = [QuestionNAnswers]()
    
    init(){
        // Creating a quiz item and appending it to the list
        let kotlinQuestionNAns = QuestionNAnswers(question : "KotlinQ1", correctAnswers: "C", noOfChoice :4)
        answerlist.append(kotlinQuestionNAns)
        //   QuestionNAnswers(questionNo : "question2", correctAnswers: "C")
        answerlist.append(QuestionNAnswers(question : "KotlinQ2", correctAnswers: "B", noOfChoice :4))
        answerlist.append(QuestionNAnswers(question : "KotlinQ3", correctAnswers: "B",noOfChoice :4))
        answerlist.append(QuestionNAnswers(question : "KotlinQ4", correctAnswers: "A",noOfChoice :3))
        answerlist.append(QuestionNAnswers(question : "KotlinQ5", correctAnswers: "B",noOfChoice :4))
    }
}
