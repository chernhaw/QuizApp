//
//  QuizData.swift
//  Quiz App
//
//  Created by tong chern haw on 19/11/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import Foundation

struct QuizSettings {
    var quizID: String
    var questionType: String
    var timeAllowed: Int
    var noOfQuestions: Int
}
