//
//  HRViewController.swift
//  Quiz App
//
//  Created by tong chern haw on 5/12/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import UIKit



class HRViewController: UIViewController {
 @IBOutlet weak var searchByID: UIButton!
    
 @IBOutlet weak var idEntered: UITextField!
    
 var idEnteredStr: String=""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func searchByIDButtonPressed(_ sender: UITextField) {
        
        idEnteredStr = "\(idEntered.text!)"
        print("ID to entered  \(idEnteredStr)")
        
       // checkIDEntered()
        saveQuizDetails()
        
    }

//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//
//       // var quizSettingsInfo = QuizSettings(quizID: "\(questionType) 01",
//        saveQuizDetails()
//        var serachParam = SearchByInfo(userID: idEnteredStr, userNRIC: "" )
//        if segue.identifier=="searchByID"{
//            let searchByIDViewController = segue.destination as! SearchTableViewController
//
//            print("ID sent to searchByIDViewController \(idEnteredStr)")
//            searchByIDViewController.userSearch=serachParam;
//        }

        
//        if segue.destination is SearchTableViewController
//        {
//            let vc = segue.destination as? SearchTableViewController
//            vc?.userSearch=serachParam;
//        }
//}
    
    func saveQuizDetails(){
        
        let searchCodable = SearchByInfo(userID:idEnteredStr, userNRIC:"")
        
       
        
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let archieveURL = documentsDirectory.appendingPathComponent("search").appendingPathExtension("plist")
        print ("file saved \(archieveURL)")
        
        let propertyListEncoder = PropertyListEncoder()
        let encodedNote = try? propertyListEncoder.encode(searchCodable)
        
        try? encodedNote?.write(to: archieveURL, options: .noFileProtection)
        
        
        //  func retrieveQuizDetails() {
        let propertyListDecoder = PropertyListDecoder()
        
        if let retrievedNoteData = try? Data(contentsOf: archieveURL),
            let decodedNote = try? propertyListDecoder.decode(SearchByInfo.self, from: retrievedNoteData) {
            print(decodedNote)
        }
        //  }
    }
    
    
    
    func checkIDEntered(){
        print("ID accessed by another method \(idEnteredStr)")
    }
}
