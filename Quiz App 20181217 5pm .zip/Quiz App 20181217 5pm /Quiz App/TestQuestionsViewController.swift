//
//  TestQuestionsViewController.swift
//  Quiz App
//
//  Created by tong chern haw on 23/11/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import UIKit
import CoreData

class TestQuestionsViewController: UIViewController {
    
    @IBOutlet weak var showJavaQuizQuestionImage: UIImageView!
    @IBOutlet weak var submitAnswerButton: UIButton!
    @IBOutlet weak var nextQuestionButton: UIButton!
    @IBOutlet weak var submitAnswer: UIButton!
    //@IBOutlet weak var previousQuestionsButton: UIButton!
   // @IBOutlet weak var quizAnswer: UITextField!
    @IBOutlet weak var selectedAnswer: UILabel!
    @IBOutlet weak var answerFeedback: UILabel!
    @IBOutlet weak var timeLeft: UILabel!
    @IBOutlet weak var testResult: UILabel!
    @IBOutlet weak var submitQuizButton: UIButton!
    @IBOutlet weak var tryAgainButton: UIButton!
    
    @IBOutlet weak var exitQuizButton: UIButton!
    
    
    @IBOutlet weak var answersLabel: UILabel!
    
    var quizAnswerStr : String = ""
    var questionNo : Int = 1
    var totalQuizQuestions : Int = 0
    var score : Int = 0
    var quizTimeAllowed : Int = 0
    var seconds = 15
    var timer = Timer()
    var quizPercentage : Double = 0.0
    
    var attempStr : String = ""
    var javaTestAnsStr : String = ""
    
    let javaCorrectAns = JavaCorrectAnswers()
    
    var allQuizResults: [QuizRecord] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getQuizDetails ()
        loadQuizAnswers()
       // checkPreviousQuizAttempt()
        startAttemp ()
        
//        showQuizQuestion(questionNoToShow : questionNo)
//        nextQuestionButton.isHidden = true
//        seconds = quizTimeAllowed * 60
//        runTimer()
        
    }
    
    func loadQuizAnswers() {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
       // var userSearch: String = "user1"
        var testType: String = "Java 01"
        let managedContext =
            appDelegate.persistentContainer.viewContext
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "JavaAnswers")
        
        //  let testtype = "Java 01"
        fetchRequest.predicate = NSPredicate(format: "quizName == %@ ", testType)
        
        do {
            
         //   print ("Try searching by \(userSearch)")
            let results = try managedContext.fetch(fetchRequest)
            
            for data in results as! [NSManagedObject]{
            
                    javaTestAnsStr = data.value(forKey: "quizAnswers") as! String
                    answersLabel.text = "Test answers \(javaTestAnsStr)"
                    print ("Test answers \(javaTestAnsStr)")
                
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        
    }
    
    func timeString(time:TimeInterval) -> String{
      //  let hours = Int(time) / 3600
        let minutes = Int(time) / 60 % 60
        let seconds = Int(time) % 60
        return String (format: "%02i:%02i",  minutes, seconds)
    }
    
    func runTimer(){
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }
    
    @objc func updateTimer(){
        if seconds > 0 {
            seconds -= 1
            timeLeft.text = timeString(time: TimeInterval(seconds))
        } else {
            timeLeft.text = "Times Up! - Submit your answers"
            nextQuestionButton.isHidden = true
         //   previousQuestionsButton.isHidden = true
            submitAnswerButton.isHidden = true
            submitQuizButton.isHidden = false
            
        }
        
    }
    
    func showQuizQuestion(questionNoToShow : Int){

      print ("\(javaCorrectAns.answerlist[questionNoToShow-1].question)")
        //diceImageView2.image = UIImage(named:diceArray[randomDiceIndex2])
        showJavaQuizQuestionImage.image = UIImage(named:"\(javaCorrectAns.answerlist[questionNoToShow-1].question).jpg")

    }
    
    
    @IBAction private func buttonTapped(_ sender: UIButton){
        let letter : String! = sender.title(for: .normal)
        print ("Choice \(letter)")
        
        quizAnswerStr = letter.replacingOccurrences(of: "Optional(", with: "")
        quizAnswerStr = letter.replacingOccurrences(of: ")", with: "")
        print ("Choice \(quizAnswerStr)")
        selectedAnswer.text = "You Selected  \(quizAnswerStr)"
        
        
    }

    
    @IBAction func submitAnswer(_ sender: Any) {
       //  quizAnswerStr = quizAnswer.text!
         print ("Answer submitted \(quizAnswerStr)")
        nextQuestionButton.isHidden = false
        submitAnswer.isHidden = true
        checkAnswer ()
        
    }
    

    @IBAction func showNextQuestion(_ sender: Any) {

        answerFeedback.text = ""
        nextQuestionButton.isHidden = true
        submitAnswer.isHidden = false
        questionNo = questionNo + 1
        selectedAnswer.text = ""
        if questionNo <= totalQuizQuestions {

            
            showQuizQuestion(questionNoToShow :questionNo)

        } else {
                nextQuestionButton.isHidden = true
                quizScore ()
        }

    }

    func checkAnswer (){
        var answerFormat = "AnswerFor\(questionNo):\(quizAnswerStr.uppercased())"
        
  
        print ("Answer format :> \(answerFormat)")
        print ("Java Answers :> \(javaTestAnsStr)")
        if ((javaTestAnsStr.range(of:answerFormat)) != nil){
            print ("Correct")
        
            answerFeedback.text = "Correct ! The answer is \(quizAnswerStr)"
            score = score + 1
            print(score)
        } else {
            answerFeedback.text = "Wrong !, answer is \(correctAns(questionNo:questionNo))"
        }
        
    }
    
    func correctAns (questionNo:Int) -> String {
     //   var correctAnsStr = ""
        
        var correctAnsStr = "AnswerFor\(questionNo):A"
        if ((javaTestAnsStr.range(of:correctAnsStr)) != nil){
            return "A"
        }
        correctAnsStr = "AnswerFor\(questionNo):B"
        
        if ((javaTestAnsStr.range(of:correctAnsStr)) != nil){
            return "B"
        }
        
        correctAnsStr = "AnswerFor\(questionNo):C"
        
        if ((javaTestAnsStr.range(of:correctAnsStr)) != nil){
            return "C"
        }
        
        correctAnsStr = "AnswerFor\(questionNo):D"
        
        if ((javaTestAnsStr.range(of:correctAnsStr)) != nil){
            return "D"
        }
        
        return "Error please check"
    }
    
    @IBAction func submitAnswers(_ sender: Any) {
         quizScore ()
         updateQuizAttempt()
        
        
    }
    
    func checkPreviousQuizAttempt() {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        var userSearch: String = "user1"
        var testType: String = "Java 01"
        let managedContext =
            appDelegate.persistentContainer.viewContext
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "UserQuizData")
        
        //  let testtype = "Java 01"
        fetchRequest.predicate = NSPredicate(format: "userid == %@ && testtype= %@", userSearch, testType)
        
        do {
            
            print ("Try searching by \(userSearch)")
            let results = try managedContext.fetch(fetchRequest)
            
            for data in results as! [NSManagedObject]{
                
                var userIdStr : String = data.value(forKey: "userid") as! String
                var resultStr = data.value(forKey: "result") as! String
                var testTypeStr = data.value(forKey: "testtype") as! String
                attempStr = data.value(forKey: "attempt") as! String
                
                
                print (testTypeStr + userIdStr + resultStr)
                let quizRecordEntry = QuizRecord(userid: userIdStr, testtype: testTypeStr, result:resultStr , attempt: "na")
                 print ( "User \(userIdStr)" + " has taken \(testTypeStr) and \(resultStr) on \(attempStr) attempts")
                allQuizResults.append(quizRecordEntry)
                
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        
    }
    
    
    func updateQuizAttempt() {
        
        checkPreviousQuizAttempt()
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "UserQuizData", in: context)
        let newUpdate = NSManagedObject(entity: entity!, insertInto: context)
        
        
         print ("Attempts so far \(attempStr)")
        
        if ( attempStr.isEmpty ){
      
            newUpdate.setValue("user1", forKey: "userid")
            newUpdate.setValue("\(quizPercentage)", forKey: "result")
            newUpdate.setValue("Java 01", forKey: "testtype")
            newUpdate.setValue("1", forKey: "attempt")
        } else {
            attempStr = attempStr.replacingOccurrences(of: "Optional(", with: "")
            attempStr = attempStr.replacingOccurrences(of: ")", with: "")
            
            var attemptInt :Int! = Int(attempStr)
            attemptInt = attemptInt+1
            
            //     var updateAttempStr : String! = String(attemptInt)
            
            newUpdate.setValue("user1", forKey: "userid")
            newUpdate.setValue("\(quizPercentage)", forKey: "result")
            newUpdate.setValue("Java 01", forKey: "testtype")
            newUpdate.setValue("\(attemptInt)", forKey: "attempt")
            
        }
       
        
        do {
            try context.save()
        } catch {
            print("Failed saving")
        }
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"UserQuizData")
        request.returnsObjectsAsFaults = false
        
        do {
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject]{
//                print(data.value(forKey:"userid") as! String)
//                print(data.value(forKey:"result") as! String)
                var userid = data.value(forKey:"userid") as? String
                var testtype = data.value(forKey:"testtype") as? String
                var result = data.value(forKey:"result") as? String
                
                print ( "Found userid: \(userid)" + ", test type: " + "\(testtype)" + " result : " + "\(result)")
            }
        } catch {
            print("Failed")
        }
    }
    
    func quizScore (){
        print ( " Score \(score)" )
        print ( " Total Question \(totalQuizQuestions)" )
        quizPercentage =  (Double(score)/Double(totalQuizQuestions))*100
        print ("Quiz Percentage \(quizPercentage)")
        if (quizPercentage > 50 ) {
            testResult.text = "You have passed - you got \(quizPercentage)"
        } else {
            testResult.text = "You have failed - you got \(quizPercentage)"
        }
        
        updateQuizAttempt()
        tryAgainButton.isHidden=false
        exitQuizButton.isHidden=false
    }
    
    
    func getQuizDetails (){

        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let archieveURL = documentsDirectory.appendingPathComponent("Java 01").appendingPathExtension("plist")

        //  func retrieveQuizDetails() {
        let propertyListDecoder = PropertyListDecoder()
        
        if let retrievedNoteData = try? Data(contentsOf: archieveURL),
            let decodedNote = try? propertyListDecoder.decode(QuizInfoSaved.self, from: retrievedNoteData) {
            print(decodedNote)
            totalQuizQuestions = Int(decodedNote.noOfQuestions)!
            quizTimeAllowed = Int(decodedNote.noOfQuestions)!
        }
        
    }

    func startAttemp () {
        
        quizAnswerStr = ""
        answerFeedback.text = ""
        testResult.text = ""
        
        questionNo = 1
        quizPercentage = 0.0
        score = 0
      //  updateQuizAttempt()
        
        print ("Ans str \(quizAnswerStr)")
        showQuizQuestion(questionNoToShow : questionNo)
        nextQuestionButton.isHidden = true
        submitQuizButton.isHidden = true
        tryAgainButton.isHidden = true
        exitQuizButton.isHidden = true
        seconds = quizTimeAllowed * 60
        
        runTimer()
        
        
    }
    
    
    @IBAction func tryAgain(_ sender: Any) {
        startAttemp ()
    }

}
