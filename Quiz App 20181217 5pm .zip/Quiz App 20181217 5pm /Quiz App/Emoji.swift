//
//  Emoji.swift
//  Quiz App
//
//  Created by tong chern haw on 5/12/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

class Emoji {
    var symbol: String
    var name: String
    var description: String
    var usage: String
    
    init(symbol: String, name: String, description: String, usage: String ){
        self.symbol = symbol
        self.name = name
        self.description = description
        self.usage = usage
    }
}
