//
//  ResultsTableViewController.swift
//  Quiz App
//
//  Created by tong chern haw on 5/12/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import UIKit
import CoreData


class ResultsTableViewController: UITableViewController {

    
    
    var allQuizResults: [QuizRecord] = []
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        // Uncomment the following line to preserve selection between presentations
//        // self.clearsSelectionOnViewWillAppear = false
//
//        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
//        // self.navigationItem.rightBarButtonItem = self.editButtonItem
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext =
            appDelegate.persistentContainer.viewContext
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "UserQuizData")
        
      //  let testtype = "Java 01"
       // fetchRequest.predicate = NSPredicate(format: "testtype == %@", testtype)
        
        do {
            let results = try managedContext.fetch(fetchRequest)
            
            for data in results as! [NSManagedObject]{
                
                var userIdStr : String = data.value(forKey: "userid") as! String
                var resultStr = data.value(forKey: "result") as! String
                var testTypeStr = data.value(forKey: "testtype") as! String
                var attempStr = data.value(forKey: "attempt") as! String
                print (testTypeStr + userIdStr + resultStr)
                let quizRecordEntry = QuizRecord(userid: userIdStr, testtype: testTypeStr, result:resultStr , attempt: attempStr)
                
                allQuizResults.append(quizRecordEntry)
               
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return allQuizResults.count
            
        } else {
            return 0
        }
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EmojiCell", for: indexPath)
        
        let quizResult = allQuizResults[indexPath.row]
        cell.textLabel?.text = "\(quizResult.userid): \(quizResult.testtype) Result : \(quizResult.result) Attempt : \(quizResult.attempt)"
      //  cell.detailTextLabel?.text = emoji.description
        return cell
    }
    
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */

}
