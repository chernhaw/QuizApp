//
//  SwiftCorrectAnswers.swift
//  Quiz App
//
//  Created by tong chern haw on 29/11/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import Foundation

class SwiftCorrectAnswers{
    var answerlist = [QuestionNAnswers]()
    
    init(){
        // Creating a quiz item and appending it to the list
        let swiftQuestionNAns = QuestionNAnswers(question : "SwiftQ1", correctAnswers: "C",noOfChoice :2)
        answerlist.append(swiftQuestionNAns)
        //   QuestionNAnswers(questionNo : "question2", correctAnswers: "C")
        answerlist.append(QuestionNAnswers(question : "SwiftQ2", correctAnswers: "B",noOfChoice :2))
        answerlist.append(QuestionNAnswers(question : "SwiftQ3", correctAnswers: "B",noOfChoice :2))
        answerlist.append(QuestionNAnswers(question : "SwiftQ4", correctAnswers: "A",noOfChoice :2))
        answerlist.append(QuestionNAnswers(question : "SwiftQ5", correctAnswers: "B",noOfChoice :2))
    }
}
