//
//  SwiftQuestionViewController.swift
//  Quiz App
//
//  Created by tong chern haw on 29/11/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import UIKit
import CoreData

class SwiftQuestionViewController: UIViewController {
    
    @IBOutlet weak var showSwiftQuizQuestion: UIImageView!
    @IBOutlet weak var submitAnswer: UIButton!
   // @IBOutlet weak var quizAnswers: UITextField!
    @IBOutlet weak var nextQuestionButton: UIButton!
    @IBOutlet weak var answerFeedback: UILabel!
    @IBOutlet weak var timeLeft: UILabel!
    @IBOutlet weak var testResult: UILabel!
    @IBOutlet weak var submitQuizButton: UIButton!
    @IBOutlet weak var tryAgainButton: UIButton!
    @IBOutlet weak var exitQuizButton: UIButton!
    @IBOutlet weak var selectedAnswer: UILabel!
    
    @IBOutlet weak var buttonA: UIButton!
    @IBOutlet weak var buttonB: UIButton!
    @IBOutlet weak var buttonC: UIButton!
    @IBOutlet weak var buttonD: UIButton!

    var quizAnswerStr : String = ""
    var questionNo : Int = 0
    var totalQuizQuestions : Int = 0
    var score : Int = 0
    var quizTimeAllowed : Int = 0
    var seconds = 15
    var timer = Timer()
    var quizPercentage : Double = 0.0
    var attempStr : String = ""
    
    let swiftCorrectAns = SwiftCorrectAnswers()
    var allQuizResults: [QuizRecord] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getQuizDetails ()
        startAttemp ()
        // Do any additional setup after loading the view.
    }
    
    func startAttemp () {
        
        quizAnswerStr = ""
        answerFeedback.text = ""
        testResult.text = ""
        
        questionNo = 0
        quizPercentage = 0.0
        score = 0
        
        showQuizQuestion(questionNoToShow : questionNo)
        nextQuestionButton.isHidden = true
        submitQuizButton.isHidden = true
        tryAgainButton.isHidden = true
        exitQuizButton.isHidden = true
        seconds = quizTimeAllowed * 60
        runTimer()
        
    }
    
    
    func getQuizDetails (){
        
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let archieveURL = documentsDirectory.appendingPathComponent("Swift 01").appendingPathExtension("plist")
        
        //  func retrieveQuizDetails() {
        let propertyListDecoder = PropertyListDecoder()
        
        if let retrievedNoteData = try? Data(contentsOf: archieveURL),
            let decodedNote = try? propertyListDecoder.decode(QuizInfoSaved.self, from: retrievedNoteData) {
            print(decodedNote)
            totalQuizQuestions = Int(decodedNote.noOfQuestions)!
            quizTimeAllowed = Int(decodedNote.timeAllowed)!
            print ("Quiz time allowed \(quizTimeAllowed)")
            
        }
        
    }
    
    func timeString(time:TimeInterval) -> String{
        //  let hours = Int(time) / 3600
        let minutes = Int(time) / 60 % 60
        let seconds = Int(time) % 60
        return String (format: "%02i:%02i",  minutes, seconds)
    }
    
    func runTimer(){
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }
    
    @objc func updateTimer(){
        if seconds > 0 {
            seconds -= 1
            timeLeft.text = timeString(time: TimeInterval(seconds))
        } else {
            timeLeft.text = "Times Up! - Submit your answers"
            nextQuestionButton.isHidden = true
            //   previousQuestionsButton.isHidden = true
            submitAnswer.isHidden = true
            submitQuizButton.isHidden = false
            
        }
        
    }
    
    func showQuizQuestion(questionNoToShow : Int){
        
        print ("\(swiftCorrectAns.answerlist[questionNoToShow].question)")
        //diceImageView2.image = UIImage(named:diceArray[randomDiceIndex2])
        showSwiftQuizQuestion.image = UIImage(named:"\(swiftCorrectAns.answerlist[questionNoToShow].question).jpg")
        
    }
    
    @IBAction func submitAnswer(_ sender: Any) {
       // selectedAnswer.text = quizAnswerStr
        print ("Answer submitted \(quizAnswerStr)")
        nextQuestionButton.isHidden = false
        submitAnswer.isHidden = true
        checkAnswer ()
        
    }
    
    func checkAnswer (){
        
        if quizAnswerStr.uppercased() == swiftCorrectAns.answerlist[questionNo].correctAnswers{
            
            answerFeedback.text = "Correct !"
            score = score + 1
            print(score)
        } else {
            answerFeedback.text = "Wrong !, answer is \(swiftCorrectAns.answerlist[questionNo].correctAnswers)"
        }
        
    }
    
    @IBAction func submitAnswers(_ sender: Any) {
        quizScore ()
        
    }
    
    @IBAction private func buttonTapped(_ sender: UIButton){
        let letter : String! = sender.title(for: .normal)
        print ("Choice \(letter)")
        
        quizAnswerStr = letter.replacingOccurrences(of: "Optional(", with: "")
        quizAnswerStr = letter.replacingOccurrences(of: ")", with: "")
        print ("Choice \(quizAnswerStr)")
        selectedAnswer.text = "You Selected  \(quizAnswerStr)"
    }
    
//    @IBAction func submitAnswer(_ sender: Any) {
//        //  quizAnswerStr = quizAnswers.text!
//        print ("Answer submitted \(quizAnswerStr)")
//        nextQuestionButton.isHidden = false
//        submitAnswer.isHidden = true
//        checkAnswer ()
//
//    }
    
    func quizScore (){
        updateQuizAttempt()
        print ( " Score \(score)" )
        print ( " Score \(totalQuizQuestions)" )
        quizPercentage =  (Double(score)/Double(totalQuizQuestions))*100
        print ("Quiz Percentage \(quizPercentage)")
        if (quizPercentage > 50 ) {
            testResult.text = "You have passed - you got \(quizPercentage)"
        } else {
            testResult.text = "You have failed - you got \(quizPercentage)"
        }
        tryAgainButton.isHidden=false
        exitQuizButton.isHidden=false
    }
    
    @IBAction func tryAgain(_ sender: Any) {
        startAttemp ()
    }
    
    @IBAction func showNextQuestion(_ sender: Any) {
        
        answerFeedback.text = ""
        
        selectedAnswer.text = ""
        nextQuestionButton.isHidden = true
        submitAnswer.isHidden = false
        questionNo = questionNo + 1
        
        if questionNo < totalQuizQuestions {
            
           
            showQuizQuestion(questionNoToShow :questionNo)
            
        } else {
            nextQuestionButton.isHidden = true
            submitAnswer.isHidden = true
            quizScore ()
        }
        
    }
    
    
    func updateQuizAttempt() {
        checkPreviousQuizAttempt()
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "UserQuizData", in: context)
        let newUpdate = NSManagedObject(entity: entity!, insertInto: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"UserQuizData")
        request.returnsObjectsAsFaults = false
        
        
        print ("Attempts so far \(attempStr)")
        attempStr = attempStr.replacingOccurrences(of: "Optional(", with: "")
        attempStr = attempStr.replacingOccurrences(of: ")", with: "")
        
        
        var attemptInt :Int! = Int(attempStr)
        attemptInt = attemptInt+1
        //  print ("Attempts so far )
        
        var updateAttempStr : String! = String(attemptInt)
        
        
        newUpdate.setValue("user1", forKey: "userid")
        newUpdate.setValue("\(quizPercentage)", forKey: "result")
        newUpdate.setValue("Swift 01", forKey: "testtype")
        newUpdate.setValue(updateAttempStr, forKey: "attempt")
        
        do {
            try context.save()
            
        } catch {
            print("Failed saving")
        }
        
        
        
        do {
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject]{
                
                var userid = data.value(forKey:"userid") as! String
                var testtype = data.value(forKey:"testtype") as! String
                var result = data.value(forKey:"result") as! String
                print ( "\(userid)" + " " + "\(testtype)" + " " + "\(result)")
                //                print(data.value(forKey:"userid") as! String)
                //                print(data.value(forKey:"testtype") as! String)
                //                print(data.value(forKey:"result") as! String)
            }
        } catch {
            print("Failed")
        }
    }
    func checkPreviousQuizAttempt() {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        var userSearch: String = "user1"
        var testType: String = "Swift 01"
        let managedContext =
            appDelegate.persistentContainer.viewContext
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "UserQuizData")
        
        //  let testtype = "Java 01"
        fetchRequest.predicate = NSPredicate(format: "userid == %@ && testtype= %@", userSearch, testType)
        
        do {
            
            print ("Try searching by \(userSearch)")
            let results = try managedContext.fetch(fetchRequest)
            
            for data in results as! [NSManagedObject]{
                
                var userIdStr : String = data.value(forKey: "userid") as! String
                var resultStr = data.value(forKey: "result") as! String
                var testTypeStr = data.value(forKey: "testtype") as! String
                attempStr = data.value(forKey: "attempt") as! String
                print (testTypeStr + userIdStr + resultStr)
                let quizRecordEntry = QuizRecord(userid: userIdStr, testtype: testTypeStr, result:resultStr , attempt: attempStr)
                print ( "User \(userIdStr)" + " has taken \(testTypeStr) and \(resultStr) on \(attempStr) attempts")
                allQuizResults.append(quizRecordEntry)
                
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        
    }


}
