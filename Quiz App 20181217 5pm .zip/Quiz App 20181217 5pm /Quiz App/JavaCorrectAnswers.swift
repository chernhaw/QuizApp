//
//  JavaCorrectAnswers.swift
//  Quiz App
//
//  Created by tong chern haw on 28/11/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import Foundation
class JavaCorrectAnswers{
    var answerlist = [QuestionNAnswers]()
    
    
    init(){
        // Creating a quiz item and appending it to the list
        let javaQuestionNAns = QuestionNAnswers(question : "JavaQ1", correctAnswers: "C", noOfChoice :4)
        answerlist.append(javaQuestionNAns)
     //   QuestionNAnswers(questionNo : "question2", correctAnswers: "C")
        answerlist.append(QuestionNAnswers(question : "JavaQ2", correctAnswers: "B" ,noOfChoice :4))
        answerlist.append(QuestionNAnswers(question : "JavaQ3", correctAnswers: "B", noOfChoice :4))
        answerlist.append(QuestionNAnswers(question : "JavaQ4", correctAnswers: "A",noOfChoice :4))
        answerlist.append(QuestionNAnswers(question : "JavaQ5", correctAnswers: "B", noOfChoice :4))
    }
    
    
}
