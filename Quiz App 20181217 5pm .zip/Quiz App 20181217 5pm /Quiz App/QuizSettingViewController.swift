//
//  QuizSettingViewController.swift
//  Quiz App
//
//  Created by tong chern haw on 17/12/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import UIKit

class QuizSettingViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    let testType = ["Java", "Kotlin", "Swift"]
    let duration = ["5","10","15"]
    let noOfQuestionChoice = ["5","10","15"]
    
    var questionType = ""
    var noOfQuestions = ""
    var timeAllowed = ""
    
    
    @IBOutlet weak var testTypePicker: UIPickerView!
    @IBOutlet weak var durationPicker: UIPickerView!
    @IBOutlet weak var selectNoOfQuestions: UIPickerView!
    @IBOutlet weak var selectedTestType: UITextField!
    @IBOutlet weak var selectedDuration: UITextField!
    @IBOutlet weak var selectTestTypeButton: UIButton!
    @IBOutlet weak var selectDurationButton: UIButton!
    @IBOutlet weak var selectedQuestionNo: UITextField!
    @IBOutlet weak var selectNoButton:UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        testTypePicker.delegate = self
        testTypePicker.dataSource = self
        testTypePicker.isHidden = true
        
        
        durationPicker.delegate = self
        durationPicker.dataSource = self
        durationPicker.isHidden = true
        
        selectNoOfQuestions.delegate = self
        selectNoOfQuestions.dataSource = self
        selectNoOfQuestions.isHidden = true
        
        selectTestTypeButton.isHidden = true
        selectDurationButton.isHidden = true
        selectNoButton.isHidden = true
        
    }
    
    
    
    
    
    @IBAction func testTypeEditingBegin(_ sender: Any) {
        testTypePicker.isHidden = false
        selectTestTypeButton.isHidden = false
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    @IBAction func testTypeChanged(_ sender: Any) {
        
        testTypePicker.isHidden = false
        selectTestTypeButton.isHidden = false
    }
    
    
    
    @IBAction func noOfQuestionTextEditing(_ sender: Any) {
        selectNoOfQuestions.isHidden = false
        selectNoButton.isHidden = false
    }
    
    
    @IBAction func selectTestTypeChanged(_ sender: UIButton) {
        //  dataSourceType  = "testType"
        testTypePicker.isHidden = true
        selectTestTypeButton.isHidden = true
    }
    
    @IBAction func durationTextFieldEditing(_ sender: Any) {
        //   dataSourceType  = "duration"
        durationPicker.isHidden = false
        selectDurationButton.isHidden = false
    }
    
    @IBAction func selectDurationButton(_ sender: Any) {
        durationPicker.isHidden = true
        selectDurationButton.isHidden = true
    }
    
    @IBAction func noOfQuestionTextFieldEditing (_ sender: Any) {
        selectNoOfQuestions.isHidden = false
        selectNoButton.isHidden = false
    }
    
    @IBAction func selectQuestionButton(_ sender: Any){
        selectNoOfQuestions.isHidden = true
        selectNoButton.isHidden = true
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == testTypePicker{
            return testType.count
            // return duration.count
        } else if ( pickerView == durationPicker){
            return duration.count
        } else if ( pickerView == selectNoOfQuestions){
            return noOfQuestionChoice.count
        }
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
        
        if pickerView == testTypePicker{
            print("testType - chosen")
            print (testType[row])
            
            selectedTestType.text = "\(testType[row])"
            questionType = "\(testType[row])"
            
            return testType[row]
            
        } else if pickerView == durationPicker {
            print("duration - chosen")
            print (duration[row])
            
            selectedDuration.text = "\(duration[row])"
            timeAllowed = "\(duration[row])"
            
            return duration[row]
            
        } else if pickerView == selectNoOfQuestions {
            print("no of question - chosen")
            print(noOfQuestionChoice[row])
            
            selectedQuestionNo.text = "\(noOfQuestionChoice[row])"
            noOfQuestions = "\(noOfQuestionChoice[row])"
            
            return noOfQuestionChoice[row]
        }
        
        return ""
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender:Any?){
        
        let timeAllowedInt = Int(timeAllowed)!
        let noOfQuestionsInt = Int(noOfQuestions)!
        print (timeAllowedInt)
        print (noOfQuestionsInt)
        
        var quizSettingsInfo = QuizSettings(quizID: "\(questionType) 01",
            questionType: questionType,
            timeAllowed: timeAllowedInt,
            noOfQuestions: noOfQuestionsInt
        )
        print (quizSettingsInfo)
        if segue.identifier == "VerifyQuizSetting"{
            let verifyViewController = segue.destination as! VerifyQuizSettingsViewController
            verifyViewController.response = quizSettingsInfo
        }
    }
    




    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
