//
//  SetQuizViewController.swift
//  Quiz App
//
//  Created by tong chern haw on 19/11/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import UIKit
import Foundation

class SetQuizViewController: UIViewController  {
    
  //  @IBOutlet var questionTypeSelected: UITextField!
    var questionType = ""
    var noOfQuestions = ""
    var timeAllowed = ""
    var response : QuizSettings!
  //  var quizSettingsInfo : QuizSettings
    
    @IBOutlet weak var checkSettingBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        checkSettingBtn.isEnabled = false
        //  questionTypeSelected.text = questionType[0]
    }
    
    @IBAction func javaQuestions(_ sender: UISwitch) {
        if sender.isOn {
            questionType = "Java"
        } else if questionType.range(of:"Java") != nil {
            questionType.replacingOccurrences(of: "Java", with: "")
        }
        
        checkAllSelected()
    }
    
    @IBAction func kotlinQuestions(_ sender: UISwitch) {
        if sender.isOn {
            questionType = "Kotlin"
        } else if questionType.range(of:"Kotlin") != nil {
            questionType.replacingOccurrences(of: "Kotlin", with: "")
        }
        
        checkAllSelected()
    }
    
    
    @IBAction func swiftQuestions(_ sender: UISwitch) {
        if sender.isOn {
            questionType = "Swift"
        }else if questionType.range(of:"Swift") != nil {
            questionType.replacingOccurrences(of: "Swift", with: "")
        }
        
        checkAllSelected()
        
    }
    
    
    @IBAction func fiveQuestions(_ sender: UISwitch) {
        if sender.isOn {
            noOfQuestions = "5"
        }else if noOfQuestions.range(of:"5") != nil {
            noOfQuestions.replacingOccurrences(of: "5", with: "")
        }
        checkAllSelected()
    }
    
    
    @IBAction func tenQuestions(_ sender: UISwitch) {
        if sender.isOn {
            noOfQuestions = "10"
        }else if noOfQuestions.range(of:"10") != nil {
            noOfQuestions.replacingOccurrences(of: "10", with: "")
        }
        
        checkAllSelected()
    }
    
    @IBAction func fifteenQuestions(_ sender: UISwitch) {
        if sender.isOn {
            noOfQuestions = "15"
        }else if noOfQuestions.range(of:"15") != nil {
            // remove 15 if the switch is OFF
            noOfQuestions.replacingOccurrences(of: "15", with: "")
        }
        checkAllSelected()
    }
    
    
    @IBAction func fiveMin(_ sender: UISwitch) {
        if sender.isOn {
            timeAllowed = "05"
        }else if timeAllowed.range(of:"05") != nil {
            // remove 5 min if the switch is OFF
            timeAllowed.replacingOccurrences(of: "05", with: "")
        }
        
        checkAllSelected()
    }
    
    
    @IBAction func tenMin(_ sender: UISwitch) {
        if sender.isOn {
            timeAllowed = "10"
        }else if timeAllowed.range(of:"10") != nil {
            timeAllowed.replacingOccurrences(of: "10", with: "")
        }
        
        checkAllSelected()
    }
    
    
    @IBAction func fifteenMin(_ sender: UISwitch) {
        if sender.isOn {
            timeAllowed = "15"
        }else if timeAllowed.range(of:"15") != nil {
            timeAllowed.replacingOccurrences(of: "15", with: "")
        }
        
        checkAllSelected()
    }
    
    func logSelection () {
        print ("Quiz Type \(questionType)")
        print ("No of Quiz Questions \(noOfQuestions)")
        print ("Time allowed \(timeAllowed)")
    }
    
    @IBAction func setQuestions(_ sender: Any) {
       
       
        logSelection ()
    
        
        
    }
    
    func checkAllSelected(){
        if (questionType != "" && noOfQuestions != "" && timeAllowed != ""){
            checkSettingBtn.isEnabled = true
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender:Any?){
        
        let timeAllowedInt = Int(timeAllowed)!
        let noOfQuestionsInt = Int(noOfQuestions)!
        print (timeAllowedInt)
        print (noOfQuestionsInt)
        
        var quizSettingsInfo = QuizSettings(quizID: "\(questionType) 01",
        questionType: questionType,
        timeAllowed: timeAllowedInt,
        noOfQuestions: noOfQuestionsInt
        )
        print (quizSettingsInfo)
        if segue.identifier == "VerifyQuizSetting"{
            let verifyViewController = segue.destination as! VerifyQuizSettingsViewController
           verifyViewController.response = quizSettingsInfo
        }
    }
    
    
}
