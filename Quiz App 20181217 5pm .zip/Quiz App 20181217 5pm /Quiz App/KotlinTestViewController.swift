//
//  KotlinTestViewController.swift
//  Quiz App
//
//  Created by tong chern haw on 29/11/18.
//  Copyright © 2018 tong chern haw. All rights reserved.
//

import UIKit

class KotlinTestViewController: UIViewController {

    @IBOutlet weak var showKotlinQuizQuestionImage: UIImageView!
    @IBOutlet weak var submitAnswerButton: UIButton!
    @IBOutlet weak var nextQuestionButton: UIButton!
    @IBOutlet weak var submitAnswer: UIButton!
    //@IBOutlet weak var previousQuestionsButton: UIButton!
    @IBOutlet weak var quizAnswer: UITextField!
    @IBOutlet weak var answerFeedback: UILabel!
    @IBOutlet weak var timeLeft: UILabel!
    @IBOutlet weak var testResult: UILabel!
    @IBOutlet weak var submitQuizButton: UIButton!
    @IBOutlet weak var tryAgainButton: UIButton!
    
    @IBOutlet weak var exitQuizButton: UIButton!
    
    var quizAnswerStr : String = ""
    var questionNo : Int = 0
    var totalQuizQuestions : Int = 0
    var score : Int = 0
    var quizTimeAllowed : Int = 0
    var seconds = 15
    var timer = Timer()
    var quizPercentage : Double = 0.0
    
    let kotlinCorrectAns = KotlinCorrectAnswers()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getQuizDetails ()
        
        startAttemp ()
        //        showQuizQuestion(questionNoToShow : questionNo)
        //        nextQuestionButton.isHidden = true
        //        seconds = quizTimeAllowed * 60
        //        runTimer()
        
    }
    
    func timeString(time:TimeInterval) -> String{
        //  let hours = Int(time) / 3600
        let minutes = Int(time) / 60 % 60
        let seconds = Int(time) % 60
        return String (format: "%02i:%02i",  minutes, seconds)
    }
    
    func runTimer(){
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }
    
    @objc func updateTimer(){
        if seconds > 0 {
            seconds -= 1
            timeLeft.text = timeString(time: TimeInterval(seconds))
        } else {
            timeLeft.text = "Times Up! - Submit your answers"
            nextQuestionButton.isHidden = true
            //   previousQuestionsButton.isHidden = true
            submitAnswerButton.isHidden = true
            submitQuizButton.isHidden = false
            
        }
        
    }
    
    func showQuizQuestion(questionNoToShow : Int){
        
        print ("\(kotlinCorrectAns.answerlist[questionNoToShow].question)")
        //diceImageView2.image = UIImage(named:diceArray[randomDiceIndex2])
        showKotlinQuizQuestionImage.image = UIImage(named:"\(kotlinCorrectAns.answerlist[questionNoToShow].question).jpg")
        
    }
    
    
    @IBAction func submitAnswer(_ sender: Any) {
        quizAnswerStr = quizAnswer.text!
        print ("Answer submitted \(quizAnswerStr)")
        nextQuestionButton.isHidden = false
        submitAnswer.isHidden = true
        checkAnswer ()
        
    }
    
    
    @IBAction func showNextQuestion(_ sender: Any) {
        
        answerFeedback.text = ""
        nextQuestionButton.isHidden = true
        submitAnswer.isHidden = false
        questionNo = questionNo + 1
        
        if questionNo < totalQuizQuestions {
            
            quizAnswer.text = ""  // clear text field for next entry
            showQuizQuestion(questionNoToShow :questionNo)
            
        } else {
            nextQuestionButton.isHidden = true
            quizScore ()
        }
        
    }
    
    func checkAnswer (){
        
        if quizAnswerStr.uppercased() == kotlinCorrectAns.answerlist[questionNo].correctAnswers{
            
            answerFeedback.text = "Correct !"
            score = score + 1
            print(score)
        } else {
            answerFeedback.text = "Wrong !, answer is \(kotlinCorrectAns.answerlist[questionNo].correctAnswers)"
        }
        
    }
    
    
    @IBAction func submitAnswers(_ sender: Any) {
        quizScore ()
        
    }
    
    func quizScore (){
        print ( " Score \(score)" )
        print ( " Score \(totalQuizQuestions)" )
        quizPercentage =  (Double(score)/Double(totalQuizQuestions))*100
        print ("Quiz Percentage \(quizPercentage)")
        if (quizPercentage > 50 ) {
            testResult.text = "You have passed - you got \(quizPercentage)"
        } else {
            testResult.text = "You have failed - you got \(quizPercentage)"
        }
        tryAgainButton.isHidden=false
        exitQuizButton.isHidden=false
    }
    
    
    func getQuizDetails (){
        
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let archieveURL = documentsDirectory.appendingPathComponent("Java 01").appendingPathExtension("plist")
        
        //  func retrieveQuizDetails() {
        let propertyListDecoder = PropertyListDecoder()
        
        if let retrievedNoteData = try? Data(contentsOf: archieveURL),
            let decodedNote = try? propertyListDecoder.decode(QuizInfoSaved.self, from: retrievedNoteData) {
            print(decodedNote)
            totalQuizQuestions = Int(decodedNote.noOfQuestions)!
            quizTimeAllowed = Int(decodedNote.noOfQuestions)!
        }
        
    }
    
    func startAttemp () {
        
        quizAnswerStr = ""
        answerFeedback.text = ""
        testResult.text = ""
        
        questionNo = 0
        quizPercentage = 0.0
        score = 0
        
        showQuizQuestion(questionNoToShow : questionNo)
        nextQuestionButton.isHidden = true
        submitQuizButton.isHidden = true
        tryAgainButton.isHidden = true
        exitQuizButton.isHidden = true
        seconds = quizTimeAllowed * 60
        runTimer()
        
    }
    
    
}
